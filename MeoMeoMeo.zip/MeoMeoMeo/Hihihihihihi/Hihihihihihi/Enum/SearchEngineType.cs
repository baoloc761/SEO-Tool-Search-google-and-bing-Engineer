﻿public enum SearchEngineType
{
    Google,
    Bing
}
